Place files that should be immutable to students in here.

